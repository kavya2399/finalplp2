import { Component, OnInit } from '@angular/core';
import data from '../../data/accountdetails.json';
@Component({
  selector: 'app-moneytransfer',
  templateUrl: './moneytransfer.component.html',
  styleUrls: ['./moneytransfer.component.css']
})
export class MoneytransferComponent implements OnInit {
  array=data
  flag=false
  array1=[];
  temp1:any
  temp2:any
  constructor() { }

  ngOnInit() {
  }
  find(number1 , number2){
    this.array.forEach(element => {
      if(element.accNum==number1 || element.accNum==number2)
      {
        this.array1.push(element)
      }
    });
    this.flag=true
  }
  transfer(number1, number2, amount){
    this.array.forEach(element => {
      if(element.accNum==number1)
      {
        this.temp1=element.balance
      }
      else if(element.accNum==number2)
      {
        this.temp2=element.balance
      }
    }
    );
    if(this.temp1>=amount)
    {
      this.temp1=this.temp1-amount
      this.temp2=this.temp2+amount
    }
    this.array.forEach(element => {
      if(element.accNum==number1)
      {
        element.balance=this.temp1;
      }
      else if(element.accNum==number2)
      {
        element.balance=this.temp2;
      }
    });
    this.flag=true
  }
}
