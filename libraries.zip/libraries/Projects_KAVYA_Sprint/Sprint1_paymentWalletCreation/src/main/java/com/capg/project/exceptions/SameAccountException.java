package com.capg.project.exceptions;

@SuppressWarnings("serial")
public class SameAccountException extends Exception 
{
  public SameAccountException()
	{
		super("The Wallet Number's cannot be same For Transfer");
	}

}
