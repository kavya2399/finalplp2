package com.capg.project.userinterface;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;


import com.capg.project.bean.Account;
import com.capg.project.service.AccountServiceImpl;

import java.util.Scanner;
import java.util.Set;

public class Starter {
	
	static AccountServiceImpl service=new AccountServiceImpl();
	public static void showMenu() 
	{
	    
		System.out.println("\nWelcome to PAYMENT WALLET");
		System.out.println("01 Create New Accountt ");
		System.out.println("02 Add money to your Account");
		System.out.println("03 Show Account Details");
		System.out.println("04 Money Transfer");
		System.out.println("05 Show All  Accounts");
		System.out.println("06 Exit");
		System.out.print("Enter Your Choice of Service : ");
	}
	public static void main(String[] args)
	{
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		int choice;
		while(true)
		{
			showMenu();
			choice = scanner.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("\n Account Creation");
					
				try
				{
					Account user=new Account();
					System.out.println("Enter your Name:");
					user.setName(scanner.next());
					System.out.println("Enter your Mobile Number:");
					user.setPhoneNumber(scanner.nextLong());
					System.out.println("Enter your E-mail Id:");
					user.setEmailid(scanner.next());
					user.setBalance(0);
					String AccountNumber=service.createAccount(user);
					System.out.println("Your Account is created successfully!!!Your Account Number is : "+AccountNumber);
					
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 2:
				System.out.println("\nAdd money to the Account");

				try {
					System.out.println("Enter the account Number to be added:");
					String AccountNumber=scanner.next();
					System.out.println("Enter the Amount to be added to the Account Number "+AccountNumber);
					int Amount=scanner.nextInt();
					service.addMoney(AccountNumber, Amount);
					System.out.println("Amount added successfully");
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 3:
				System.out.println("\nView Account Details");
				try
				{
					System.out.println("Enter the Account Number:");
					String AccountNumber=scanner.next();
					Account user=service.viewAccount(AccountNumber);
					System.out.println("Name:"+user.getName()+"\nPhone:"+user.getPhoneNumber()+"\nEmail:"+user.getEmailid()+"\nBalance:"+user.getBalance());
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 4:
				System.out.println("\nMoney Transfer");
				try
				{
					System.out.println("Enter the Sender's Account Number:");
					String SenderAccountNumber=scanner.next();
					System.out.println("Enter the Reciever's Account Number:");
					String RecieverAccountNumber=scanner.next();
					System.out.println("Enter the Amount to be Transferred:");
					int TransferAmount=scanner.nextInt();
					service.transfer(SenderAccountNumber, RecieverAccountNumber, TransferAmount);
					System.out.println("Amount transfered successfully");
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 5:
				try
				{
					Map<String, Account> userlist=new HashMap<String, Account>();
					userlist=service.getAllAccounts();
					if(!userlist.isEmpty())
					{

						Set<Entry<String, Account>> set=userlist.entrySet();
						Iterator<Entry<String, Account>> i=set.iterator();
						while(i.hasNext())
						{
							Map.Entry<String, Account> me=(Map.Entry<String, Account>)i.next();
							Account result=me.getValue();
							System.out.println("\nThe Available Accounts are...");
							System.out.println("Account Number: "+me.getKey()+"\nUser Name: "+result.getName());
						}
					}
					else
					{
						System.out.println("No Accounts Found");
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
				break;
			case 6:
				System.out.println("Thank you for using");
				System.exit(0);
			default:
				System.out.println("No Services Found");
				break;
			}
		}
	}

}
