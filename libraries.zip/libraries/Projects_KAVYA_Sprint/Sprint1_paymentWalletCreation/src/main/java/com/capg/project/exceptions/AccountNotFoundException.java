package com.capg.project.exceptions;

@SuppressWarnings("serial")
public class AccountNotFoundException extends Exception{
	public AccountNotFoundException()
	{
		super("Check the Wallet Number you have Entered");
	}

}
